#pragma once
#include <cstring>
#include <iostream>
#include <vector>
#include "Product.h"
#include "UserList.h"
using namespace std;
class Store
{
private:
	vector<Product*> elements;
	UserList users;
	int find(const Product& prod);
	Store();
public:
	Store(const Store& cpy) = delete;
	Store& operator=(const Store& cpy) = delete;
	~Store();

	const Product& getProduct(int index) const;
	Product& getProduct(int index);

	static Store& getStore();
	int getNumberOfProducts() const;
	void addProduct(const Product& prod);
	void deleteProduct(const Product& prod);
	void reduceQuantity(const Product& prod, int quantity);
	void displayProducts() const;
	void filterByPrice(float LowPrice, float HighPrice) const;
	void filterByQuantity(int Low, int High) const;
	void filterByBrand(const string& Brand) const;
	void buyProductsinCart(const User& user);
	void addProductToCart(const string& username, const string& password, int id, int quantity);
	void removeProductFromCart(const User& user, int id);
	int viewNumberofProductsInCart(const User& user)const;
	void listProductsInCart(const User& user) const;

	void registerInStore(const User& user);
	int getNumberOfUsers() const;
	void removeAccountFromStore(const User& u);
	bool changeUserPassword(const string& username, const string& oldPassword, const string& newPassword);
	void listUsers() const;

};
