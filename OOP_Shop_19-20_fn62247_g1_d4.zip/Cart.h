#pragma once
#include "Product.h"
#include <vector>
#include "User.h"
#include "Pair.h"
class Cart
{
private:

	vector<Pair<Product*, int>> products;
	int find(const Product& prod) const;
public:
	Cart();
	Cart(const Cart& par);
	Cart& operator=(const Cart& par);
	~Cart();
	int size() const;
	void addToCart(const Product& prod, int quantity);
	bool removeProductFromCart(const Product& prod);
	bool changeQuantity(const Product& prod, int newQuantity);
	void clearCart();
	void viewCart() const;
	bool isConsistProduct(int id) const;
	Pair<Product*, int>& operator[](int index);
	const Pair<Product*, int>& operator[](int index) const;
};

