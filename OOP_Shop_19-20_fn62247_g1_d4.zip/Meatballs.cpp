#include "Meatballs.h"

Meatballs::Meatballs(): animal(pig), expirationDate()
{
	setType(Type::Meatballs);
	setBrand("");
	setDescription("");
	setPrice(0.0);
	setCount(0);
	
}

Meatballs::Meatballs(const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar, Date expirationDatePar, Animal animalPar):animal(animalPar), expirationDate(expirationDatePar)
{
	setType(Type::Meatballs);
	setBrand(brandPar);
	setModel(modelPar);
	setDescription(descriptionPar);
	setPrice(pricePar);
	setCount(countPar);
}

Date Meatballs::getExpirationDate() const
{
	return expirationDate;
}

Meatballs::Animal Meatballs::getAnimal() const
{
	return animal;
}

void Meatballs::print() const
{
	cout << *this;
}

Meatballs* Meatballs::clone() const
{
	Meatballs* copy = new Meatballs(*this);
	return copy;
}

ostream& operator<<(ostream& os, const Meatballs& b)
{
	os << b.getID() << ' '<<"Meatballs"<<' ' << b.getBrand() << ' ' << b.getModel() << ' ' << b.getDescription() << ' ' << b.getPrice() << ' ' << b.getCount()<<' '<<b.expirationDate<<' ';
	switch (b.animal) {
	case Meatballs::pig: return os << "pig" << ' '; break;
	case Meatballs::chicken: return os << "chicken" << ' '; break;
	case Meatballs::veal: return os << "veal" << ' '; break;
	default: return os << "other" << ' '; break;
	}
}

istream& operator>>(istream& is, Meatballs& m)
{
	int t;
	is >> t;
	m.setType(Product::Type::Meatballs);
	string desc;
	std::getline(is, desc);
	m.setDescription(desc);
	float pr;
	is >> pr;
	if (pr < 0)  throw logic_error("Price must be >0.");
	m.setPrice(pr);
	int c;
	is >> c;
	if (c < 0) throw logic_error("Count must be >0.");
	m.setCount(c);
	is >> m.expirationDate;
	is >> t;
	if (t >= 0 && t <= 2) m.animal = static_cast<Meatballs::Animal>(t);
	else m.animal = static_cast<Meatballs::Animal>(0);
	return is;
}
