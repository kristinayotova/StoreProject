#include <iostream>
#include "User.h"
#include <vector>
#include "UserList.h"
#include "Store.h"
#include "String.h"
#include "Meatballs.h"
#include "Blouse.h"

using namespace std;
void user() {
	User user1("Krisi", "1234"), user2("Pesho", "55889"), user3("Gosho", "77844"), user4("Admin", "12345");
	Store& myStore = Store::getStore();
	myStore.registerInStore(user1);
	myStore.registerInStore(user2);
	myStore.registerInStore(user3);
	myStore.registerInStore(user4);
	Blouse prod2("br2", "mod2", " this is prod2", 22.00, 2,Blouse::Size::XS,Blouse::Color::colorful); 
	Meatballs prod3( "br3", "mod3", " this is prod3", 130.00, 3,Date(10,5,2020),Meatballs::Animal::pig);
	Blouse prod1( "br1", "mod1", " this is prod1", 12.50, 14, Blouse::Size::XL, Blouse::Color::white);
	Meatballs prod4( "br4", "mod4", " this is prod4", 205.00, 30, Date(10, 7, 2020), Meatballs::Animal::veal);
	Blouse prod5("br5", "mod5", " this is prod5", 7.00, 24, Blouse::Size::S, Blouse::Color::black);
	Meatballs prod6( "br6", "mod6", " this is prod6", 410.00, 5, Date(21, 12, 2020), Meatballs::Animal::pig);
	Blouse prod7( "br7", "mod7", " this is prod7", 12.50, 6, Blouse::Size::XS, Blouse::Color::colorful);
	Meatballs prod8( "br8", "mod8", " this is prod8", 785.00, 12, Date(12, 7, 2020), Meatballs::Animal::chicken);
	Blouse prod9("br9", "mod9", " this is prod9", 8.00, 10, Blouse::Size::L, Blouse::Color::white);
	Meatballs prod10( "br10", "mod10", " this is prod10", 340.00, 28, Date(23, 8, 2020), Meatballs::Animal::chicken);
	myStore.addProduct(prod1);
	myStore.addProduct(prod2);
	myStore.addProduct(prod3);
	myStore.addProduct(prod4);
	myStore.addProduct(prod5);
	myStore.addProduct(prod6);
	myStore.addProduct(prod7);
	myStore.addProduct(prod8);
	myStore.addProduct(prod9);
	myStore.addProduct(prod10);
	cout << "Option Menu:" << endl << "1 - Register account" << endl << "2 - Remove account" << endl << "3 - Change password" << endl
		<< "4 - View number of users in store" << endl << "5 - View users in store" << endl << "6 - View number of products in store" << endl << "7 - View products in store" << endl
		<< "8 - Add product to cart" << endl << "9 - Remove product from cart" << endl << "10 - Filter products by price" << endl << "11 - Filter products by quantity" << endl
		<< "12 - Filter products by brand" << endl << "13 - View number of products in cart" << endl << "14 - View products in cart" << endl
		<< "15 - Buy products in cart" << endl;
	int option;
	cout << "Please select option!" << endl;
	cin >> option;
	while (option != 0) {
		switch (option) {
		case 1: {
			cout << "Add user (username,password). Username and password must be only one word. " << endl;
			User user5;
			cin >> user5;
			int help = 0;
			try {
				myStore.registerInStore(user5);
			}
			catch (exception & e) {
				cout << e.what() << endl;
				help = 1;
			}
			if (help == 0) cout << "Successful registration." << endl;
			break;
		}
		case 2: {
			cout << "For removing your account. Please enter username and password." << endl;
			string username, password;
			cin >> username >> password;
			User temp(username, password);
			int help = 0;
			try {
				myStore.removeAccountFromStore(temp);
			}
			catch (exception & e) {
				cout << e.what() << endl;
				help = 1;
			}
			if (help == 0) cout << "Successful remove account." << endl;
			break;
		}
		case 3: {
			cout << "For changing password. Please enter username, old password and new password." << endl;
			string username, password, newpass;
			cin >> username >> password >> newpass;
			bool result = myStore.changeUserPassword(username, password, newpass);
			if (result == true) cout << "You successful change password." << endl;
			else cout << "You didn't change your password" << endl;
			break;
		}
		case 4: {
			cout << "Number of users is: " << myStore.getNumberOfUsers() << endl;
			break;
		}
		case 5: {
			cout << "List of users:" << endl;
			myStore.listUsers();
			break;
		}
		case 6: {
			cout << "Number of products is: " << myStore.getNumberOfProducts() << endl;
			break;
		}
		case 7: {
			cout << "List of products:" << endl << "(id, type{ 1 - Blouse,2 - Meatballs }, brand, model, description, price, count,expirationDate/size,animal/color)" << endl;
			myStore.displayProducts();
			break;
		}
		case 8: {
			cout << "Add product to cart. Please enter username, password, id of product, quantity." << endl;
			string username, password;
			int id, quantity;
			cin >> username >> password >> id >> quantity;
			int help = 0;
			try {
				myStore.addProductToCart(username, password, id, quantity);
			}
			catch (exception & e) {
				help = 1;
				cout << e.what() << endl;
			}
			if (help == 0) cout << "You successful add product with ID: " << id << " to your cart." << endl;
			break;
		}
		case 9: {
			cout << "To remove product from your cart please enter username,password,id of product." << endl;
			string username, password;
			cin >> username >> password;
			int id;
			cin >> id;
			User user(username, password);
			int help = 0;
			try {
				myStore.removeProductFromCart(user, id);
			}
			catch (const exception & e) {
				help = 1;
				cout << e.what() << endl;
			}
			if (help == 0) cout << "You sucessfully remove product with id:" << id << " of your cart." << endl;
			break;
		}
		case 10: {
			cout << "You want to filter products by price. Please enter interval." << endl;
			int min, max;
			cin >> min >> max;
			try {
				myStore.filterByPrice(min, max);
			}
			catch (exception & e) {
				cout << e.what() << endl;
			}
			break;
		}
		case 11: {
			cout << "You want to filter products by quantity. Please enter interval." << endl;
			int min, max;
			cin >> min >> max;
			try {
				myStore.filterByQuantity(min, max);
			}
			catch (exception & e) {
				cout << e.what() << endl;
			}
			break;
		}
		case 12: {
			cout << "You want to filter products by brand.Please enter brand." << endl;
			string brand;
			cin >> brand;
			myStore.filterByBrand(brand);
			break;
		}
		case 13: {
			cout << "To see the products in the cart please enter username and password." << endl;
			string username, password;
			cin >> username >> password;
			User user(username, password);
			int number = myStore.viewNumberofProductsInCart(user);
			if (number == -1) cout << "No such a user."<<endl;
			else cout << "In cart you have " << number << " products." << endl;
			break; }
		case 14: {
			cout << "Please enter username and password." << endl;
			string username, password;
			cin >> username >> password;
			User user(username, password);
			cout << "List of products in cart:" << endl;
			myStore.listProductsInCart(user);
			break;
		}
		case 15: {
			cout << "Please enter username and password." << endl;
			string username, password;
			cin >> username >> password;
			User user(username, password);
			myStore.buyProductsinCart(user);
			break;
		}
		}
		cout << "Please select option!" << endl;
		cin >> option;
	}
}
int main() {
	try {
		user();
	}
	catch (exception & e) {
		cout << e.what();
	}
}