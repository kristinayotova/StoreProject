#pragma once
#include <iostream>
#include <iomanip>
using namespace std;
class Date
{
private:
	int day;
	int month;
	int year;
public:
	Date();
	Date(int dayPar, int monthPar, int yearPar);
	
	int getDay() const;
	int getMonth() const;
	int getYear() const;

	void setDay(int dayPar);
	void setMonth(int monthPar);
	void setYear(int yearPar);

	friend std::ostream& operator<<(std::ostream& os, const Date& date);
	friend std::istream& operator>>(std::istream& is, Date& date);
	bool isCorrectDate()const;

};

