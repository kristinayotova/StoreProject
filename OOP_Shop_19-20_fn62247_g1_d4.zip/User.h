#pragma once
#include <string>
#include <cstring>
#include <iostream>
#include "Cart.h"
using namespace std;

class User
{
	string username;
	string password;
public:
	User();
	User(const string& usernamePar, const string& passwordPar);
	//User(const User& user);
	//User& operator=(const User& user);
	//~User();

	void setUsername(const string& usernamePar);

	const string& getUsername() const;

	bool operator==(const User& user) const;
	friend ostream& operator<<(ostream& os, const User& user);
	friend istream& operator>>(istream& is, User& user);

	//dali yspeshno e smenena parolata
	bool changePassword(const string& oldPassword, const string& newPassword);

};

