#include "Product.h"
int Product::counter = 0;
Product::Product() :ID(counter++), brand(), model(), description(), price(0.0), count(0), type(Blouse)
{


}

Product::Product(Type typePar, const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar)
	:ID(counter++), brand(brandPar), model(modelPar), description(descriptionPar), price(pricePar), count(countPar), type(typePar)
{

}

/*Product::Product(const Product& cpy) :ID(cpy.ID), brand(cpy.brand), model(cpy.brand), price(cpy.price), count(cpy.count)
{

}*/

/*Product& Product::operator=(const Product& cpy)
{
	if (this != &cpy) {
		ID = cpy.ID;
		price = cpy.price;
		count = cpy.count;
		brand = cpy.brand;
		model = cpy.model;
	} return*this;
}*/

Product::~Product()
{

}

void Product::setBrand(const string& brandPar)
{
	brand = brandPar;
}

void Product::setModel(const string& modelPar)
{
	model = modelPar;
}

void Product::setDescription(const string& descriptionPar)
{
	description = descriptionPar;
}

void Product::setPrice(float pricePar)
{
	if (pricePar < 0) throw std::logic_error("Price must be >0");
	price = pricePar;
}

void Product::setCount(int countPar)
{
	if (countPar < 0) throw std::logic_error("Count must be >0");
	count = countPar;
}

void Product::setType(Type typePar)
{
	type = typePar;
}

int Product::getID() const
{
	return ID;
}

const string& Product::getBrand() const
{
	return brand;
}

const string& Product::getModel() const
{
	return model;
}

const string& Product::getDescription() const
{
	return description;
}

float Product::getPrice() const
{
	return price;
}

int Product::getCount() const
{
	return count;
}

Product::Type Product::getType() const
{
	return type;
}

void Product::print() const
{
	cout << *this;
}


bool Product::operator==(const Product& prod) const
{
	return ID == prod.ID;
}

std::ostream& operator<<(std::ostream& os, const Product& p)
{
	os << p.ID << ' ';
	switch (p.type) {
	case Product::Blouse: os << "Blouse" << ' '; break;
	case Product::Meatballs: os << "Phone" << ' '; break;
	default: os << "other" << ' '; break;
	}
	return os << p.brand << ' ' << p.model << ' ' << p.description << ' ' << p.price << ' ' << p.count;
}

istream& operator>>(istream& is, Product& prod)
{
	int t;
	is >> t >> prod.brand >> prod.model;
	if (t >= 0 && t <= 1) prod.type = static_cast<Product::Type>(t);
	else prod.type = static_cast<Product::Type>(0);
	std::getline(is, prod.description);
	is >> prod.price >> prod.count;
	if (prod.price < 0 || prod.count < 0) throw logic_error("Price and count must be >0.");
	return is;
}
