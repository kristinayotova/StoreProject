#pragma once
template <class T, class Q>
struct Pair {
public:
	T first;
	Q second;
	Pair() :first(), second() {

	}
	Pair(const T& firstPar, const Q& secondPar) : first(firstPar), second(secondPar) {
	}

};
