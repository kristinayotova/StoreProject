#include "User.h"

User::User() : username(), password()
{
}

User::User(const string& usernamePar, const string& passwordPar) : username(usernamePar), password(passwordPar) {

}

/*User::User(const User& user):username(user.username),password(user.password)
{

}
*/
/*User& User::operator=(const User& user)
{
	if (this != &user) {
		username = user.username;
		password = user.password;
	}
	return *this;
}*/

/*User::~User()
{

}*/

void User::setUsername(const string& usernamePar)
{
	username = usernamePar;
}

const string& User::getUsername() const
{
	return username;
}


bool User::operator==(const User& user) const
{
	return username == user.username && password == user.password;

}

bool User::changePassword(const string& oldPassword, const string& newPassword)
{
	if (oldPassword == password) {
		password = newPassword;
		return true;
	}
	return false;
}


ostream& operator<<(ostream& os, const User& user)
{
	return os << user.username;
}

istream& operator>>(istream& is, User& user)
{
	return is >> user.username >> user.password;


}

