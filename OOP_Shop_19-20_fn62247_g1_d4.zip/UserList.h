#pragma once
#include "User.h"
#include<vector>
#include <stdexcept>
#include <iostream>
using namespace std;
class UserList
{
private:
	vector<Pair<User, Cart>> elements;
	//funkciq koqto namira dali daden potrebitel syshtestvyva samo po potreb ime i vrushta indeksa
	int findUsername(const User& user);
	//po potr ime i parola
	int find(const User& user);
public:
	//UserList();
	//UserList(const UserList& cpy);
	//UserList& operator=(const UserList& cpy);
	//~UserList();

	int getSize()const;

	Pair<User, Cart>& operator[](int index);
	const Pair<User, Cart>& operator[](int index) const;


	friend ostream& operator<<(ostream& os, const UserList& ulist);

	void registerAccount(const User& user);
	void removeAccount(const User& user);

};


