#include "Store.h"

int Store::find(const Product& prod)
{
	for (int i = 0; i < elements.size(); i++) {
		if (*elements[i] == prod) return i;
	}
	return -1;
}

Store::Store()
{
}

Store::~Store()
{
	for (int i = 0; i < elements.size(); i++) {
		delete elements[i];
	}
}

const Product& Store::getProduct(int index) const
{
	return *elements[index];
}

Product& Store::getProduct(int index)
{
	return *elements[index];
}

Store& Store::getStore()
{
	static Store st;
	return st;
}

void Store::listUsers() const
{
	cout << users;
}

int Store::getNumberOfProducts() const
{
	return elements.size();
}

void Store::registerInStore(const User& user)
{
	users.registerAccount(user);
}

void Store::addProduct(const Product& prod)
{
	int index = find(prod);
	if (index >= 0) {
		(*elements[index]).setCount((*elements[index]).getCount() + prod.getCount());
	}
	else { 
		Product* cloning=prod.clone();
		elements.push_back(cloning); 
	}
}

void Store::deleteProduct(const Product& prod)
{
	int index = find(prod);
	if (index < 0) throw logic_error("Cannot delete this product.");
	delete elements[index];
	for (int i = index; i < elements.size() - 1; i++) {
		elements[i] = elements[i + 1];
	}
	elements.pop_back();
}

void Store::reduceQuantity(const Product& prod, int quantity)
{
	if (quantity < 0) throw logic_error("Quantity must be > 0.");
	int position = find(prod);
	(*elements[position]).setCount((*elements[position]).getCount() - quantity);
}

void Store::displayProducts() const
{
	for (int i = 0; i < elements.size(); i++)
	{
		if ((*elements[i]).getCount() > 0)
		{
			elements[i]->print();
			cout << endl;
		}
	}
}

void Store::filterByPrice(float LowPrice, float HighPrice) const
{
	if (LowPrice < 0 || HighPrice < 0) throw logic_error("Prices must be >0");
	if (LowPrice > HighPrice) throw logic_error("Low Price must be smaller or equal than High Price.");

	for (int i = 0; i < elements.size(); i++) {
		if (LowPrice <= (*elements[i]).getPrice() && HighPrice >= (*elements[i]).getPrice()) {
			elements[i]->print();
			cout << endl;
		}
	}
}

void Store::filterByQuantity(int Low, int High) const
{
	if (Low < 0 || High < 0) throw logic_error("Quantitis must be >0");
	if (Low > High) throw logic_error("Low Quantity must be smaller or equal than High Quantity.");
	for (int i = 0; i < elements.size(); i++) {
		if (Low <= elements[i]->getCount() && High >= elements[i]->getCount())
		{
			elements[i]->print();
			cout << endl;
		}
	}
}

void Store::filterByBrand(const string& Brand) const
{
	bool help = 0;
	for (int i = 0; i < elements.size(); i++) {
		if (elements[i]->getBrand() == Brand) {
			elements[i]->print();
			cout << endl;
			help = true;
		}
	}
	if (help == false) cout << "There are no products of this brand." << endl;
}

void Store::buyProductsinCart(const User& user)
{
	for (int i = 0; i < users.getSize(); i++) {
		if (user == users[i].first) {
			for (int j = 0; j < users[i].second.size(); j++) {
				reduceQuantity(*(users[i].second[j].first), users[i].second[j].second);
			}
			users[i].second.clearCart();
			return;
		}
	}
	throw logic_error("There is no such user.");
}

void Store::addProductToCart(const string& username, const string& password, int id, int quantity)
{
	if (quantity <= 0) throw logic_error("Quantity must be >0.");
	User temp(username, password);
	Product* prod=nullptr;
	int j = 0;
	for (j = 0; j < elements.size(); j++) {
		if (elements[j]->getID() == id) {
			prod = elements[j];
			break;
		}
	}
	if (j == elements.size()) throw logic_error("There is no such product.");
	for (int i = 0; i < users.getSize(); i++) {
		if (users[i].first == temp) {
			users[i].second.addToCart(*prod, quantity);
			return;
		}
	}
	throw logic_error("There is no such user.");
}

void Store::removeProductFromCart(const User& user, int id)
{
	int i = 0;
	for (i = 0; i < users.getSize(); i++) {
		if (users[i].first == user) {
			int j = 0;
			int len = users[i].second.size();
			for (j = 0; j < users[i].second.size(); j++) {
				if ((*users[i].second[j].first).getID() == id) {
					Product* prod = users[i].second[j].first;
					users[i].second.removeProductFromCart(*prod);
					break;
				}
			}
			if (j == len) throw logic_error("There is no such product.");
			break;
		}
	}
	if (i == users.getSize()) throw logic_error("There is no such user.");
}

int Store::viewNumberofProductsInCart(const User& user) const
{
	for (int i = 0; i < users.getSize(); i++) {
		if (users[i].first == user) {
			return users[i].second.size();
		}
	}
	return -1;
}

void Store::listProductsInCart(const User& user) const
{
	for (int i = 0; i < users.getSize(); i++) {
		if (users[i].first == user) {
			users[i].second.viewCart();

		}
	}
}

int Store::getNumberOfUsers() const
{
	return users.getSize();
}

void Store::removeAccountFromStore(const User& u)
{
	users.removeAccount(u);
}

bool Store::changeUserPassword(const string& username, const string& oldPassword, const string& newPassword)
{
	for (int i = 0; i < users.getSize(); i++) {
		if (users[i].first.getUsername() == username) {
			return users[i].first.changePassword(oldPassword, newPassword);
		}
		return false;
	}
}
