#include "UserList.h"


int UserList::findUsername(const User& user)
{
	for (int i = 0; i < elements.size(); i++) {
		if (elements[i].first.getUsername() == user.getUsername()) return i;
	}
	return -1;
}

int UserList::find(const User& user)
{
	for (int i = 0; i < elements.size(); i++) {
		if (elements[i].first == user) return i;
	}
	return -1;
}


int UserList::getSize() const
{
	return elements.size();
}

Pair<User, Cart>& UserList::operator[](int index)
{
	if (index < 0 || index >= elements.size() - 1) throw logic_error("Invalid index");
	return elements[index];
}

const Pair<User, Cart>& UserList::operator[](int index) const
{
	return elements[index];
}

void UserList::registerAccount(const User& user)
{
	if (findUsername(user) >= 0) throw logic_error("Exist user with this username!");
	Pair<User, Cart> p;
	p.first = user;
	elements.push_back(p);
}

void UserList::removeAccount(const User& user)
{
	int index = find(user);
	if (index < 0) throw logic_error("There is no user with that username and password! Cannot remove this account!");
	for (int i = index; i < elements.size() - 1; i++) {
		elements[i] = elements[i + 1];
	}
	elements.pop_back();
}

ostream& operator<<(ostream& os, const UserList& ulist)
{
	for (int i = 0; i < ulist.elements.size(); i++) {
		os << ulist[i].first << endl;
	}
	return os;
}

