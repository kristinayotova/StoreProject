#pragma once
#include<string>
#include <iostream>
#include <cstring>
using namespace std;
class Product
{
public:
	enum Type {
		Blouse, Meatballs
	};
private:
	static int counter;
	Type type;
	int ID;
	string brand;
	string model;
	string description;
	float price;
	int count;//broi nalichni 
public:
	Product();
	Product(Type typePar, const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar);
	//Product(const Product& cpy);
	//Product& operator=(const Product& cpy);
	virtual ~Product();


	void setBrand(const string& brandPar);
	void setModel(const string& modelPar);
	void setDescription(const string& descriptionPar);
	void setPrice(float pricePar);
	void setCount(int countPar);
	void setType(Type typePar);

	int getID() const;
	const string& getBrand() const;
	const string& getModel() const;
	const string& getDescription() const;
	float getPrice() const;
	int getCount() const;
	Type getType() const;
	virtual void print() const;
	virtual Product* clone() const = 0;

	bool operator==(const Product& prod) const;
	friend ostream& operator<<(ostream& os, const Product& prod);
	friend istream& operator>>(istream& is, Product& prod);

};

