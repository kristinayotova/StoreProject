#include "Cart.h"

int Cart::find(const Product& prod) const
{
	for (int i = 0; i < products.size(); i++) {
		if (*(products[i].first) == prod) {
			return i;
		}
	}
	return -1;
}

Cart::Cart(): products()
{
	
}

Cart::Cart(const Cart& par)
{
	
	for (int i = 0; i < par.products.size(); i++) {
		Pair<Product*, int> temp(par.products[i].first->clone(), par.products[i].second);
		products.push_back(temp);
	}
}

Cart& Cart::operator=(const Cart& par)
{
	if (this != &par) {
		for (int i = 0; i < products.size(); i++) {
			delete products[i].first;
		}
		products.clear();
		for (int j = 0; j < par.products.size(); j++) {
			Pair<Product*, int> temp(par.products[j].first->clone(), par.products[j].second);
			products.push_back(temp);
		}
	}
	return *this;
}

Cart::~Cart()
{
	for (int i = 0; i < products.size(); i++) {
		delete products[i].first;
	}
}

int Cart::size() const
{
	return products.size();
}

void Cart::addToCart(const Product& prod, int quantity)
{	
	if (quantity > prod.getCount()) throw logic_error("Not enough quantity.");
	Pair<Product*, int> p(prod.clone(), quantity);
	products.push_back(p);
}

bool Cart::removeProductFromCart(const Product& prod)
{
	int index = find(prod);
	if (index < 0) return false;
	delete products[index].first;
	products[index] = products[products.size() - 1];
	products.pop_back();
	return true;
}

bool Cart::changeQuantity(const Product& prod, int newQuantity)
{
	if (newQuantity <= 0) {
		throw logic_error("Quantity must be > 0");
	}
	if (newQuantity < prod.getCount()) {
		throw logic_error("Not enough quantity.");
	}
	int index = find(prod);
	if (index < 0) {
		throw logic_error("Cannot find such a product.");
	}
	products[index].second = newQuantity;
	return true;

}

void Cart::clearCart()
{
	int len = products.size();
	for (int i = 0; i < len; i++) {
		delete products[len-i-1].first;
		products.pop_back();
	}
}

void Cart::viewCart() const
{
	for (int i = 0; i < products.size(); i++) {
		products[i].first->print();
		cout<< products[i].second << endl;

	}
}

bool Cart::isConsistProduct(int id) const
{
	for (int i = 0; i < products.size(); i++) {
		if (id == products[i].first->getID()) return true;
	}
	return false;
}

Pair<Product*, int>& Cart::operator[](int index)
{
	return products[index];
}

const Pair<Product*, int>& Cart::operator[](int index) const
{
	return products[index];
}

