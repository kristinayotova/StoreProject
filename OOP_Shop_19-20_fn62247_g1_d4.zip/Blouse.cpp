#include "Blouse.h"

Blouse::Blouse():Product(),size(universal), color(colorful)
{

	setType(Type::Blouse);
	
}

Blouse::Blouse( const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar, Size sizePar, Color colorPar):size(sizePar),color(colorPar)
{
	setType(Type::Blouse);
	setBrand(brandPar);
	setModel(modelPar);
	setDescription(descriptionPar);
	setPrice(pricePar);
	setCount(countPar);
}

void Blouse::print() const
{
	cout << *this;
}

Blouse::Size Blouse::getSize() const
{
	return size;
}

Blouse::Color Blouse::getColor() const
{
	return color;
}

Blouse* Blouse::clone() const
{
	Blouse* copy = new Blouse(*this);
	return copy;
}

ostream& operator<<(ostream& os, const Blouse& b)
{
	os << b.getID() <<' '<<"Blouse"<<' '<< b.getBrand() << ' ' << b.getModel() << ' ' << b.getDescription() << ' ' << b.getPrice() << ' ' << b.getCount()<<' ';
	switch (b.size) {
	case Blouse::universal: os << "universal" << ' '; break;
	case Blouse::XS: os << "XS" << ' '; break;
	case Blouse::S: os << "S" << ' '; break;
	case Blouse::M: os << "M" << ' '; break;
	case Blouse::L: os << "L" << ' '; break;
	case Blouse::XL: os << "XL" << ' '; break;
	default: os << "other" << ' '; break;
	}
	switch (b.color) {
	case Blouse::white: return os << "white" << ' '; break;
	case Blouse::black: return os << "black" << ' '; break;
	case Blouse::colorful: return os << "colourful" << ' '; break;
	default: return os << "other" << ' '; break;
	}
}

istream& operator>>(istream& is, Blouse& b)
{
	int t;
	is >> t;
	b.setType(Product::Type::Blouse);
	string desc;
	getline(is, desc);
	b.setDescription(desc);
	float pr;
	is >> pr;
	if (pr<0)  throw logic_error("Price must be >0.");
	b.setPrice(pr);
	int c;
	is >> c;
	if(c<0) throw logic_error("Count must be >0.");
	b.setCount(c);
	is >> t;
	if (t >= 0 && t <= 5) b.size = static_cast<Blouse::Size>(t);
	else b.size = static_cast<Blouse::Size>(0);
	is >> t;
	if (t >= 0 && t <= 2) b.color = static_cast<Blouse::Color>(t);
	else b.color = static_cast<Blouse::Color>(t);
	return is;
}
