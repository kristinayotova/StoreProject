#include "Date.h"

Date::Date():day(1),month(1),year(2000)
{
}

Date::Date(int dayPar, int monthPar, int yearPar): day(dayPar),month(monthPar), year(yearPar)
{

}

int Date::getDay() const
{
	return day;
}

int Date::getMonth() const
{
	return month;
}

int Date::getYear() const
{
	return year;
}

void Date::setDay(int dayPar)
{ 
	day = dayPar;
}

void Date::setMonth(int monthPar)
{
	month = monthPar;
}

void Date::setYear(int yearPar)
{
	year = yearPar;
}

bool Date::isCorrectDate() const
{
	if (day <= 0 || day > 31 || month <= 0 || month > 12 || year <= 0) return false;
	switch (month) {
	case 1: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 2: {
		if (((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) && day <= 29 || day <= 28) return true;
		else return false;
		break;
	}
	case 3: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 4: {
		if (day <= 30) return true;
		else return false;
		break;
	}
	case 5: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 6: {
		if (day <= 30) return true;
		else return false;
		break;
	}
	case 7: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 8: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 9: {
		if (day <= 30) return true;
		else return false;
		break;
	}
	case 10: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	case 11: {
		if (day <= 30) return true;
		else return false;
		break;
	}
	case 12: {
		if (day <= 31) return true;
		else return false;
		break;
	}
	}
}

std::ostream& operator<<(std::ostream& os, const Date& date)
{
	return os << setw(2) << setfill('0')<< date.day << "." << setw(2) << setfill('0') << date.month << "." << setw(2) << setfill('0') << date.year;
}

std::istream& operator>>(std::istream& is, Date& date)
{
	int d, m, y;
	return is >> d >> m >> y;
	if (date.isCorrectDate()) {
		date.day = d;
		date.month = m;
		date.year = y;
	}
	else throw std::logic_error("Date is not correct.");
}


