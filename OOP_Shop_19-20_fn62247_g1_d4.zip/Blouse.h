#pragma once
#include "Product.h"
class Blouse: public Product
{
public:
	enum Size {
		universal,XS,S,M,L,XL
	};
	enum Color {
		white,black,colorful
	};
private:
	Size size;
	Color color;
public:
	Blouse();
	Blouse( const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar,Size sizePar,Color colorPar);
	void print() const override;
	
	Size getSize() const;
	Color getColor() const;
	Blouse* clone() const override;
	
	friend ostream& operator<<(ostream& os, const Blouse& b);
	friend istream& operator>>(istream& is, Blouse& b);
};

