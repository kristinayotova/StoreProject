#pragma once
#include "Date.h"
#include "Product.h"
class Meatballs: public Product
{
public:
	enum Animal {
		pig,chicken,veal
	};
private:
	Date expirationDate;
	Animal animal;
public:
	Meatballs();
	Meatballs( const string& brandPar, const string& modelPar, const string& descriptionPar, float pricePar, int countPar, Date expirationDatePar, Animal animalPar);

	Date getExpirationDate() const;
	Animal getAnimal() const;
	void print() const override;
	Meatballs* clone() const override;

	friend ostream& operator<<(ostream& os, const Meatballs& m);
	friend istream& operator>>(istream& is, Meatballs& m);
};

